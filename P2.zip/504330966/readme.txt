Project 2
Name: Shuang Wang	Email: wangshuang@ucla.edu
Name: Haoxiang Zhang	Email: haoxiangzhx@gmail.com

Description:
Shuang and Haoxiang pair-programmed.
